# explorez_votre_ville
    L’objectif de ce projet est de concevoir une application Flutter nommée ExplorezVotreVille permettant à un utilisateur de découvrir, sauvegarder et commenter des lieux intéressants (restaurants, parcs, musées, cafés, monuments, etc.) dans une ville au choix.

## Choix techniques

### 1. APIs utilisées
Pour enrichir l’application avec des informations météo, géographiques et touristiques, plusieurs APIs ont été intégrées :  

- **OpenWeatherMap API**  
  - Fournit les données météorologiques pour une ville ou pour des coordonnées GPS (température, conditions, humidité, etc.).  
  - Exemple d’appel :  
    ```
    fetchCityInfoFromOWM("Paris");
    getCityWithCoordonates(48.8566, 2.3522);
    ```  

- **Geoapify Places & Geocoding API**  
  - Recherche des lieux d’intérêt autour d’une ville ou selon une catégorie spécifique (musées, restaurants…).  
  - Géolocalisation inversée : obtenir les informations d’un lieu à partir de ses coordonnées.  
  - Exemple d’appel :  
    ```
    getCityPlaces(48.8566, 2.3522); 
    getCityPlacesAvecCategorie(48.8566, 2.3522, "entertainment.museum");
    getLieuInfo(48.8566, 2.3522);
    ```  

- **Google Street View API**  
  - Permet de récupérer une image Street View pour un lieu donné.  
  - Exemple d’appel :  
    ```
    getStreetViewImageUrl("Tour Eiffel", lat: 48.8584, lon: 2.2945);
    ```
### 2. Gestion de l’état avec Provider
- Utilisation de **Provider** pour gérer l’état des données dans Flutter.  
- ``LieuProvider``:  utiliser dans la sauvgarde temporaire d'un lieu lors de vue des details, modification etc...
-`ThemeProvider` : pour la gestion du thème de l'application


### 3. Modèle de données et stockage local
- **SQLite** pour stocker localement certaines informations et permettre une consultation hors ligne.  
- Modèles principaux :  
  - `Meteo` : informations météorologiques d’une ville ou d’un lieu.  
  - `Lieu` : point d’intérêt avec coordonnées, catégorie et ville.  
  - `LieuInfo` : détails supplémentaires via géolocalisation.   

### NB: certainnes fonctions d'apis ou classes n'ont pas forcement d'usage dans le code. cela est dû à des modifications faites tout en long du proje

## Structure du projet

Le projet est structuré selon les bonnes pratiques Flutter, avec une organisation claire entre logique métier, UI et ressources :  


### Points clés
- **`lib/models`** : Contient les classes représentant les données manipulées (météo, lieux, etc.).  
- **`lib/db`** : Gestion locale des données via SQLite pour un accès hors ligne.  
- **`lib/listeners`** : Contient les `ChangeNotifier` et Provider pour la gestion de l’état global.  
- **`lib/screens`** : Chaque écran de l’application est organisé ici.  
- **`lib/widgets`** : Widgets réutilisables pour la mise en page et les composants UI.  
- **`lib/utils`** : Fonctions utilitaires 


## Limites et compatibilité

L'application a été principalement testée sur **Windows**, où elle fonctionne correctement.  

Cependant, certaines plateformes peuvent rencontrer des problèmes :  

- **Web** : la base de données SQLite n'étant pas pleinement supportée, certaines fonctionnalités peuvent provoquer des anomalies ou des erreurs inattendues.  
- **Émulateurs Android/iOS** : des comportements imprévus peuvent survenir, et certaines anomalies n'ont pas pu être complètement élucidées.  

**Remarque :** Il est donc recommandé de privilégier l'exécution sur Windows pour un usage stable de l'application.
